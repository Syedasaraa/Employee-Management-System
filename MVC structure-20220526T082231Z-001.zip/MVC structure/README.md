# 470_MVC_EMS
An MVC structured Employee management system project
